Clausulado largo en letra pequeña, botón 'acepto los términos y firmar'. Rutas: /wizard/datos, /wizard/verificacion, /wizard/firma, /wizard/resumen
Env vars: RESEND_API_KEY, TO_EMAIL.
